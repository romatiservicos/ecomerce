<?php
// Heading
$_['heading_title']    = 'Relatório de produtos visualizados';

// Text
$_['text_list']        = 'Listando produtos visualizados';
$_['text_success']     = 'Visualizações redefinidas!';

// Column
$_['column_name']      = 'Produto';
$_['column_model']     = 'Modelo';
$_['column_viewed']    = 'Visualizações';
$_['column_percent']   = 'Porcentagem';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para acessar o relatório de produtos visualizados!';