<?php
// Heading
$_['heading_title']    = 'Sub-total';

// Text
$_['text_extension']   = 'Extensões';
$_['text_success']     = 'Sub-total modificado com sucesso!';
$_['text_edit']        = 'Editando Sub-total';

// Entry
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão Sub-total!';