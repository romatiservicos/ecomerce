<?php
// Heading
$_['heading_title']    = 'Lay-Buy Layout';

// Text
$_['text_extension']   = 'Extensões';
$_['text_success']     = 'Lay-Buy Layout modificado com sucesso!';
$_['text_edit']        = 'Editando Lay-Buy Layout';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão Lay-Buy Layout!';