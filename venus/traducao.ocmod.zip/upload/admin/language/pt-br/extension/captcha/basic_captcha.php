<?php
// Heading
$_['heading_title']    = 'Captcha básico';

// Text
$_['text_extension']   = 'Extensões';
$_['text_success']     = 'Captcha básico modificado com sucesso!';
$_['text_edit']        = 'Editando Captcha básico';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar a extensão Captcha básico!';