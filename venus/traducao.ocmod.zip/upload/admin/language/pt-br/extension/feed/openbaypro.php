<?php
// Heading
$_['heading_title']  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Módulos';
$_['text_installed'] = 'A extensão OpenBay Pro já está instalada. Ela está disponível no menu Extensões -> OpenBay Pro';