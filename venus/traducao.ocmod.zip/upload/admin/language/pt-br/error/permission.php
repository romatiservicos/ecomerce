<?php
// Heading
$_['heading_title']   = 'Permissão negada!';

// Text
$_['text_permission'] = 'Você não tem permissão para acessar esta página, consulte o administrador do loja para mais informações.';