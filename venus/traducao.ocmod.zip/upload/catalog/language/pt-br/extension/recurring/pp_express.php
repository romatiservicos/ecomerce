<?php
// Text
$_['text_title']          = 'PayPal Express Checkout';
$_['text_canceled']       = 'Você cancelou com sucesso a assinatura!';

// Button
$_['button_cancel']       = 'Cancelar assinatura';

// Error
$_['error_not_cancelled'] = 'Erro: %s';
$_['error_not_found']     = 'Não foi possível cancelar a assinatura!';