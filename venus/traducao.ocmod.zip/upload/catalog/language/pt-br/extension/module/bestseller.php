<?php
// Heading
$_['heading_title'] = 'Mais vendidos';

// Text
$_['text_tax']      = 'Sem impostos:';