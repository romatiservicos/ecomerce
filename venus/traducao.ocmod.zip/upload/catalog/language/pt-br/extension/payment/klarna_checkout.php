<?php
// Heading
$_['heading_title']               = 'Klarna Checkout';
$_['heading_title_success']       = 'Seu pedido Klarna Checkout foi adicionado!';

// Text
$_['text_title']                  = 'Klarna Checkout';
$_['text_basket']                 = 'Carrinho de compras';
$_['text_checkout']               = 'Finalizar pedido';
$_['text_success']                = 'Sucesso';
$_['text_choose_shipping_method'] = 'Escolha o método de envio';
$_['text_sales_tax']              = 'Impostos';