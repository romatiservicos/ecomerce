<?php
// Text
$_['text_title']		   = 'Cartão de crédito ou débito (Authorize.Net)';
$_['text_credit_card']     = 'Detalhes do cartão';

// Entry
$_['entry_cc_owner']       = 'Títular do cartão';
$_['entry_cc_number']      = 'Número do cartão';
$_['entry_cc_expire_date'] = 'Expira em';
$_['entry_cc_cvv2']		   = 'Código de segurança (CVV2)';