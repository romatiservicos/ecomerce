<?php
// Heading
$_['heading_title']      = 'Pagamentos de comissões';

// Column
$_['column_date_added']  = 'Paga em';
$_['column_description'] = 'Descrição';
$_['column_amount']      = 'Comissão (%s)';

// Text
$_['text_account']       = 'Programa de afiliados';
$_['text_transaction']   = 'Histórico de comissões';
$_['text_balance']       = 'O seu saldo é:';
$_['text_empty']         = 'Você ainda não recebeu comissões!';