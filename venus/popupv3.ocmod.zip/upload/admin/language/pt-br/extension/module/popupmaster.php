<?php
// Heading
$_['heading_title']    = 'Popup ao Adicionar ao Carrinho';

// Text
$_['text_module']      = 'Módulos';
$_['text_success']     = 'Módulo Popup modificado com sucesso!';
$_['text_edit']        = 'Editar Módulo Popup';

// Entry
$_['entry_status']    = 'Situação';


// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar esse módulo!';