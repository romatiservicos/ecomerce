<?php
// Heading
$_['heading_title']    = 'Popup Add Cart';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Hide Price module!';
$_['text_edit']        = 'Edit Installment Simulator Module';

// Entry
$_['entry_status']    = 'Status';


// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Installment Simulator module!';