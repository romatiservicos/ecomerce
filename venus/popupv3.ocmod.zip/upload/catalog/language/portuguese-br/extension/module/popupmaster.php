<?php
// Heading
$_['titulo'] = 'Confirmação de Pedido';
$_['carrinho'] = 'Visualizar Carrinho';
$_['continuar'] = 'Continuar Comprando';
$_['comprar'] = 'Finalizar Compra';