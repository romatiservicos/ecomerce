<?php
// Heading
$_['titulo'] = 'Order Confirm';
$_['carrinho'] = 'View Cart';
$_['continuar'] = 'Shopping Cart';
$_['comprar'] = 'Checkout';