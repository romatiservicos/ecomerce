<?php
//Text
$_['text_desconto']  = 'Desconto (%s)';
$_['text_acrescimo'] = 'Acréscimo (%s)';
$_['text_boleto']    = 'Boleto';
$_['text_cartao']    = 'Cartão de Crédito';
$_['text_debito']    = 'Débito/Transferência';